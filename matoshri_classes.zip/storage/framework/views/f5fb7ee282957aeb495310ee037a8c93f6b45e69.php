<?php $__env->startSection('content'); ?>
<style type="text/css">
  /*@media  only screen and (max-width: 600px) {
 .location-table
 {
   background-color: lightblue;
 }
 }*/
/*@media(min-width: 400px) and (max-width: 600px) {
   .fontsize{
    font-size: 10px;
   }
   }*/
   .container {
    width: 10px !important;
  }
/*.table-bordered
{
  width: 300px!important;
  }*/
  @media  only screen and (max-width: 600px) {
   .table-bordered {
     width: 300px!important;
   }
 }
</style>

<div id="content-container">

  <div class="pageheader">
    
    <div id="page-content">

      <div class="panel">
                        <!--     <div class="panel-heading">
                              <h3 class="panel-title">Add Row</h3>
                            </div> -->
                          <!--   <div id="demo-custom-toolbar2" class="table-toolbar-left">
                             <a href="<?php echo e(config('app.baseURL')); ?>/user/loction"><button id="demo-dt-addrow-btn" class="btn btn-pink">Add row</button></a>
                           </div> -->
                           <div class="panel-heading ">
                            <h3 class="panel-title">Location List <!-- <a href="<?php echo e(config('app.baseURL')); ?>/employee/add" class="pull-right"><button  class="btn btn-pink">Add Location</button></a> --></h3>
                            
                          </div>
                          <div class="panel-body">
                            <table class="fontsize table table-bordered location-table  " id="myTable"  style="">
                              <thead>
                                <tr>
                                 <th>Location Id</th>
                                 <th>Latitude</th>

                                 <th>Longitude</th>
                                 
                                 <th>Created At</th>
                                 
                               </tr>
                             </thead>
                             <tbody>

                             </tbody>
                           </table>
                         </div>
                       </div>
                       <!--===================================================-->
                       <!-- End Add Row -->
                     </div>
                     <!--===================================================-->
                     <!--End page content-->
                   </div>

                   <script type="text/javascript">
                    $(document).ready(function(){
                      $("#myTable").dataTable({
                        "processing": true,
                        "serverSide": true,
                        "responsive": true,
                        ajax:"<?php echo e(config('app.baseURL')); ?>/location/allData/",
                        "order":[
                        [0,"asc"]
                        ],
                        "columns":[
                        {
                          "mData":"location_id"
                        },{
                          "mData":"latitude"
                        },{
                          "mData":"longitude"
                        },
                        {
                          "mData":"created_at"
                        },]
                      });
                    });
                  </script>
                  <script>

                    <?php if(Session::has('message')): ?>
                    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
                    switch(type){
                      case 'info':
                      toastr.info("<?php echo e(Session::get('message')); ?>");
                      break;

                      case 'warning':
                      toastr.warning("<?php echo e(Session::get('message')); ?>");
                      break;
                      case 'success':
                      toastr.success("<?php echo e(Session::get('message')); ?>");
                      break;
                      case 'error':
                      toastr.error("<?php echo e(Session::get('message')); ?>");
                      break;
                    }
                    <?php endif; ?>
                  </script>
                  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_workspace\htdocs\employeetracking.com\resources\views/user/location.blade.php ENDPATH**/ ?>