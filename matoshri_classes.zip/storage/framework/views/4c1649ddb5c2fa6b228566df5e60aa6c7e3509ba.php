 
<?php $__env->startSection('content'); ?>
<style type="text/css">
    #container.mainnav-full #page-content {
    padding: 10px 20px 0px!important;
}
</style>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/toaster.css')); ?>" />
 <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
 <script type="text/javascript" src="<?php echo e(asset('js/toaster.min.js')); ?>"></script>
             <div id="container" class="effect mainnav-full">
            <!--NAVBAR-->
            <!--===================================================-->
          
            <!--===================================================-->
            <!--END NAVBAR-->
            <div class="boxed">
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container">
                   
                    <div class="pageheader">
                    <!--     <h3><i class="fa fa-home"></i> Form Layout </h3>
                        <div class="breadcrumb-wrapper">
                            <span class="label">You are here:</span>
                            <ol class="breadcrumb">
                                <li> <a href="#"> Home </a> </li>
                                <li class="active"> form layout </li>
                            </ol>
                        </div> -->
                    </div>
                    <!--Page content-->
                    <!--===================================================-->
                    <div id="page-content">
                    
                        <div class="row">
                            <div class="eq-height">
                                <div class="col-sm-6 eq-box-sm">
                                    <div class="panel">
                                        <div class="panel-heading">
                                            <div class="panel-control">
                                                <!-- <button class="btn btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></button>
                                                <button class="btn btn-default" data-click="panel-reload"><i class="fa fa-refresh"></i></button>
                                                <button class="btn btn-default" data-click="panel-collapse"><i class="fa fa-chevron-down"></i></button>
                                                <button class="btn btn-default" data-dismiss="panel"><i class="fa fa-times"></i></button> -->
                                            </div>
                                            <h3 class="panel-title">Add Employee</h3>
                                        </div>
                                        <!--Block Styled Form -->
                                        <!--===================================================-->
                                        <form method="post" action="<?php echo e(config('app.baseURL')); ?>/employee/add">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Name</label>
                                                            <input type="text" id="demo-text-input" name="name" class="form-control" placeholder="Name" pattern="[a-zA-Z/s]+" required/>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Mobile Number</label>
                                                            <input type="text" id="cno" name="contact_number" class="form-control" placeholder="Mobile Number" pattern="[0-9]{10}" required/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Email</label>
                                                            <input type="email"  id="email" name="email" class="form-control" placeholder="Email" pattern="[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}" required/>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Password</label>
                                                            <input type="password" id="password" name="password" class="form-control" placeholder="Password" required/>
                                                        </div>
                                                    </div>
                                                </div>

                                                     <div class="row">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label class="control-label">Address</label>
                                                            <textarea id="address" rows="1" class="form-control" name="address" placeholder="Address" required/></textarea>
                                                        </div>
                                                    </div>
                                                   <!--    -->
                                                </div>
                                            </div>
                                            <div class="panel-footer text-right">
                                                <button class="btn btn-info" type="submit">Submit</button>
                                            </div>
                                        </form>
                                        <!--===================================================-->
                                        <!--End Block Styled Form -->
                                    </div>
                                </div>
                                <div class="col-sm-6 eq-box-sm">
                                 
                                </div>
                            </div>
                        </div>
                       
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
                </div>
              
              
                <!--END RIGHT CHAT MESSANGER--> 
                <!--===================================================-->
            </div>
          
            <!--===================================================-->
            <button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
            <!--===================================================-->
        </div>
       <script>

  <?php if(Session::has('message')): ?>
  var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
  switch(type){
    case 'info':
    toastr.info("<?php echo e(Session::get('message')); ?>");
    break;

    case 'warning':
    toastr.warning("<?php echo e(Session::get('message')); ?>");
    break;
    case 'success':
    toastr.success("<?php echo e(Session::get('message')); ?>");
    break;
    case 'error':
    toastr.error("<?php echo e(Session::get('message')); ?>");
    break;
  }
  <?php endif; ?>
</script>

                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_workspace\htdocs\employeetracking.com\resources\views/user/add.blade.php ENDPATH**/ ?>