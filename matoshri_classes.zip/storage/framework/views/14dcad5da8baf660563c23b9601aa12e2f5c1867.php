<?php $__env->startSection('content'); ?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<style type="text/css">
.btn-info
{
    margin-left: 30px!important;
}
.btn-danger
{
    margin-left: 30px!important;
}
.btn-success
{
    margin-left: 30px!important;
}

@media  only screen and (max-width: 600px) {
    .table-bordered {
        width:245px!important;
    }
    .pagemrgn
    {
        margin-top: 85px!important;
    }
}

</style>
<div id="content-container" style="padding-top: 0px;" >
<div class="pageheader">
<div id="page-content">
<div class="panel">

<div class="panel-heading ">
<h3 class="panel-title">All Booking &nbsp;&nbsp;  <?php echo $__env->make('layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</h3>
</div>

<div class="panel-body">
<table class="table table-bordered col-md-12 col-sm-12" id="myTable" style="" >
<thead>
<tr>
<th>Client</th>
<th>Celebrity</th>
<th>Amount</th>
<th>transaction_id</th>
<th>Action</th>
</tr>
</thead>
<tbody>

</tbody>
</table>
</div>
</div>

</div>

</div>
</div>
<div id="id01" class="w3-modal">
    <div class="w3-modal-content" style='width: 30% !important; ' >
      <div class="w3-container">
        <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-display-topright">&times;</span><br>
        <p>   <center> What do you want to do? <br> </center> </p><br><br>
        <span> <a id="accept" onclick=""> <button type='submit' class='btn btn-success'>Accept</button></span> </a>
        <a id="rejected"  text-align-last: right; href=""><button type='submit' class='btn btn-success'>rejected</button></a>
        <br>
        <br>
      </div>
    </div>
  </div>

  <div id="id011" class="w3-modal">
    <div class="w3-modal-content" style='width: 30% !important; height: 40% !important; ' >
      <div class="w3-container">
        <span onclick="document.getElementById('id011').style.display='none'" class="w3-button w3-display-topright">&times;</span><br>
       <form  method="post" action="<?php echo e(config('app.baseURL')); ?>/booking/accept" >
                <input id="id12" type="hidden" value="" name="id" /><br>
                <label class="control-label"> Enter Date </label><label style="color:red;" class="control-label">*</label><br>
                <input id="stheDate" type="date" name="s_date"/><br><br>
                <label class="control-label"> Enter Time </label><label style="color:red;" class="control-label">*</label><br>
                <input type="time" id="appt" name="time" required><br><br>
                <button class="btn btn-info" type="submit">Confirm</button>

       </form> 
       
      </div>
    </div>
  </div>


<script type="text/javascript">
$(document).ready(function(){
    $("#myTable").dataTable({
        "processing": true,
        "serverSide": true,
        "responsive": true,
        ajax:"<?php echo e(config('app.baseURL')); ?>/booking/adddata/",
        "order":[
            [0,"asc"]
        ],
        "columns":[
            {
                "mData":"client.name"
            },{
                "mData":"celebrity.name"
            },{
                "mData":"amount"
            },{
                "mData":"transaction_id"
            },
            {
                "targets":-1,
                "mData": "Action",
                "bSortable": false,
                "ilter":false,
                "mRender": function(data, type, row){
                    if (row.state == 1) {
                        return "<a class=datatable-left-link  onclick='openModal("+row.booking_id+")'><span><button type='submit' class='btn btn-primary'>Panding</button></span></a>";
                    }
                    if (row.state == 2) {
                        return "<button type='submit' class='btn btn-primary'>Conform</button>";
                    }else{
                        return "<button type='submit' class='btn btn-primary'>Cancel</button>";
                    }
                },
                
            },]
            
        });
    });
    </script>
    <script>
        function openModal(data){
                      document.getElementById('id01').style.display='block';
                      $("#accept").attr('onclick',"openAccetModal("+ data +")");
                      $("#rejected").attr('href',"<?php echo e(config('app.baseURL')); ?>/booking/status/rejected/"+data);
                    }


    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
    switch(type){
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;
            
            case 'warning':
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break;
                case 'success':
                    toastr.success("<?php echo e(Session::get('message')); ?>");
                    break;
                    case 'error':
                        toastr.error("<?php echo e(Session::get('message')); ?>");
                        break;
                    }
                    <?php endif; ?>
                    function openAccetModal(data){
                        document.getElementById('id01').style.display='none'
                        document.getElementById('id011').style.display='block';
                        $("#id12").attr('value', data );
                    }
                    </script>
                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp_workspace\htdocs\celebritybooking\resources\views/booking/all.blade.php ENDPATH**/ ?>