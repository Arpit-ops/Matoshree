<?php $__env->startSection('content'); ?>
<style type="text/css">
.videosize {
    position: absolute;
    height: 100%;
    object-fit: initial;
}



</style>

<section style="height: 600px;" >
  <div class="overlay-wcs"></div>
  <video class="videosize" playsinline="playsinline" autoplay="autoplay" muted="true" loop="loop">
    <source src="<?php echo e(config('app.baseURL')); ?>/storage/app/video/video.mp4" type="video/mp4">
  </video>
  <div class="container h-100">
    <div class="d-flex h-100 text-center align-items-center">
      <div class="w-100 text-white">
        <!-- <h1 style="color:#cccc00;">Matoshree Classes</h1>
        <p class="lead mb-0">We are Matoshree</p> -->
      </div>
    </div>
  </div>
</section>
<br><br>

<div class="container">
            <div class="row">
                <div class="offset-xl-2 col-xl-8 offset-lg-2 col-lg-8 col-md-12 col-sm-12 col-12 text-center">
                    <!-- section-title -->
                    <div class="section-title">
                        <h2>Proud of you Matoshreeans</h2>
                        <p>_</p>
                    </div>
                </div>
                <!-- /.section-title -->
            </div>
  <div class='row'>
    <div class='colmedia-md-8' style="width: 100%;">
      <div class="carousel slide media-carousel" id="media">
        <div class="carousel-inner">


          <div class="item  active">
            <div class="row">



              <div class="col-md-4">
                <div class="">
                    <div class="video-testimonial-block">
                        <div class="video">
                           <iframe width="560" height="315" src="https://www.youtube.com/embed/5VjRfvbKRGE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <!-- <a href="#" class="video-play"></a> -->
                    </div>
                    <div class="video-testimonial-content">
                        <h4 class="mb10">Shubham Ahire Proud Of You </h4>
                       <!--  <p>Retirement Planning</p> -->
                    </div>
                </div>
              </div>  


              <div class="col-md-4">
                                <div class="">
                    <div class="video-testimonial-block">
                        <div class="video">
                           <iframe width="560" height="315" src="https://www.youtube.com/embed/3IhRXnodqPE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <!-- <a href="#" class="video-play"></a> -->
                    </div>


                      <div class="video-testimonial-content">
                        <h4 class="mb10">Gayatri Pelmahale we are proud of you</h4>
                       <!--  <p>Retirement Planning</p> -->
                    </div>
                </div>
              </div>

              <div class="col-md-4">
                                <div class="">
                    <div class="video-testimonial-block">
                        <div class="video">
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/4s57SfsEbVA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                     <!--    <a href="#" class="video-play"></a> -->
                    </div>
                   <div class="video-testimonial-content">
                        <h4 class="mb10">Anant Dhondage proud of you and fan of you</h4>
                        <!-- <p>Retirement Planning</p> -->
                    </div>
                </div>
              </div>        
            </div>
          </div>


          <div class="item">
            <div class="row">

              <div class="col-md-4">
                   <div class="">
                    <div class="video-testimonial-block">
                        <div class="video">
                          <iframe width="560" height="315" src="https://www.youtube.com/embed/XOaDiRtC2yU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <!-- <a href="#" class="video-play"></a> -->
                    </div>
                    <div class="video-testimonial-content">
                        <h4 class="mb10">Aditi Deshpande proud of you</h4>
                        <!-- <p>Retirement Planning</p> -->
                    </div>
                </div>
              </div>  

              <div class="col-md-4">
                                <div class="">
                    <div class="video-testimonial-block">
                        <div class="video">
                           <iframe width="560" height="315" src="https://www.youtube.com/embed/_KleOQbwDsI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <!-- <a href="#" class="video-play"></a> -->
                    </div>
                    <div class="video-testimonial-content">
                        <h4 class="mb10">Kiran Tuse Proud of You</h4>
                        <!-- <p>Retirement Planning</p> -->
                    </div>
                </div>
              </div>




              <div class="col-md-4">
                                <div class="">
                    <div class="video-testimonial-block">
                        <div class="video">
                            <iframe width="560" height="315" src="https://www.youtube.com/embed/emS7_QliZZc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <!-- <a href="#" class="video-play"></a> -->
                    </div>
                    <div class="video-testimonial-content">
                        <h4 class="mb10">Matoshree Moments</h4>
                        <!-- <p>Retirement Planning</p> -->
                    </div>
                </div>
              </div>        
            </div>
          </div>



          <div class="item">
            <div class="row">
              <div class="col-md-4">
                                <div class="">
                    <div class="video-testimonial-block">
                        <div class="video">
                           <iframe width="560" height="315" src="https://www.youtube.com/embed/4ZvKhNoAKww" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <!-- <a href="#" class="video-play"></a> -->
                    </div>
                    <div class="video-testimonial-content">
                        <h4 class="mb10">Proud Of You Matoshreeans</h4>
                       <!--  <p>Retirement Planning</p> -->
                    </div>
                </div>
              </div>     
            </div>
          </div>
     

        </div>
        <a data-slide="prev" style="margin-top: 80px!important;border: 1px solid #FFFFFF;" href="#media" class="left carousel-control">‹</a>
        <a data-slide="next" style="margin-top: 80px!important;border: 1px solid #FFFFFF;" href="#media" class="right carousel-control">›</a>
      </div>                          
    </div>
  </div>
</div>















    <br><br><br><br>
<aside id="fh5co-hero">
		<div class="flexslider">
			<ul class="slides" >
		   	<li>
		   		<div class="overlay-gradient"></div>
		   		<div class="container" style="background: #424242;">
		   			<div class="row">
			   			<div class="col-md-8 col-md-offset-2 text-center slider-text">
			   				<div class="slider-text-inner">
			   					<h1>Education is the manifestation of the perfection already in you.</h1>
									<h2>Brought to you by <a>Swami Vivekananda</a></h2>
									<p><a class="btn btn-primary btn-lg" href="#">Start Learning Now!</a></p>
			   				</div>
			   			</div>
			   		</div>
		   		</div>
		   	</li>
		   	<li>
		   		<div class="overlay-gradient"></div>
		   		<div class="container"style="background:red;">
		   			<div class="row">
			   			<div class="col-md-8 col-md-offset-2 text-center slider-text">
			   				<div class="slider-text-inner">
			   					<h1>Arise Awake and stop till not rhe goal is reach.</h1>
									<h2>Brought to you by <a>Swami Vivekananda</a></h2>
									<p><a class="btn btn-primary btn-lg" href="#">Start Learning Now!</a></p>
			   				</div>
			   			</div>
			   		</div>
		   		</div>
		   	</li>
		   	<li>
		   		<div class="overlay-gradient"></div>
		   		<div class="container"style="background: #424242;">
		   			<div class="row">
			   			<div class="col-md-8 col-md-offset-2 text-center slider-text">
			   				<div class="slider-text-inner">
			   					<h1>Education is not information its transformation.</h1>
									<h2>Brought to you by <a>Swami Vivekananda</a></h2>
									<p><a class="btn btn-primary btn-lg" href="#">Start Learning Now!</a></p>
			   				</div>
			   			</div>
			   		</div>
		   		</div>
		   	</li>
		   	<li>
		   		<div class="overlay-gradient"></div>
		   		<div class="container"style="background: red;">
		   			<div class="row">
			   			<div class="col-md-8 col-md-offset-2 text-center slider-text">
			   				<div class="slider-text-inner">
			   					<h1>Purusharth Charitrya Udarta.</h1>
									<h2>Brought to you by <a>Swami Vivekananda</a></h2>
									<p><a class="btn btn-primary btn-lg" href="#">Start Learning Now!</a></p>
			   				</div>
			   			</div>
			   		</div>
		   		</div>
		   	</li>
		   	<li>
		   		<div class="overlay-gradient"></div>
		   		<div class="container"style="background: red;">
		   			<div class="row">
			   			<div class="col-md-8 col-md-offset-2 text-center slider-text">
			   				<div class="slider-text-inner">
			   					<h1>All differences in this world are of degree, and not of kind, because oneness is the secret of everything.</h1>
									<h2>Brought to you by <a>Swami Vivekananda</a></h2>
									<p><a class="btn btn-primary btn-lg" href="#">Start Learning Now!</a></p>
			   				</div>
			   			</div>
			   		</div>
		   		</div>
		   	</li>
		   	<li>
		   		<div class="overlay-gradient"></div>
		   		<div class="container"style="background: #424242;">
		   			<div class="row">
			   			<div class="col-md-8 col-md-offset-2 text-center slider-text">
			   				<div class="slider-text-inner">
			   					<h1>Truth can be stated in a thousand different ways, yet each one can be true.</h1>
									<h2>Brought to you by <a>Swami Vivekananda</a></h2>
									<p><a class="btn btn-primary btn-lg" href="#">Start Learning Now!</a></p>
			   				</div>
			   			</div>
			   		</div>
		   		</div>
		   	</li>	   	
		  	</ul>
	  	</div>
	</aside>





   
    <div  style="background-image: url(http://localhost/matoshri_classes/assets/bg.png);">

	<div id="fh5co-course-categories"  >
		<div class="container" >
			<div class="row animate-box">
				<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
					<h2 style="color: rgb(26, 3, 3);">Why Matoshri</h2>
					<p>__</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-3 col-sm-6 text-center animate-box">
					<div class="services">
						<span class="icon" style="color: rgb(36, 3, 3);">
							 <i class="icon-shop"></i> 
						</span>
						<div class="desc">
							<h3><a href="#"  style="color: rgb(12, 0, 0);">Academic Excellence</a></h3>
							<p>Excellent private secondary schools provide richer educational curriculum to capture the abilities of each student.</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 text-center animate-box">
					<div class="services">
						<span class="icon" style="color: rgb(20, 3, 3);">
							 <i class="icon-heart4"></i> 
						</span>
						<div class="desc">
							<h3><a href="#" style="color: rgb(22, 2, 2);">Support Facilities</a></h3>
							<p>Private educational institutions are known to offer modern learning facilities to provide opportunities for students to participate in academic and non-academic activities.</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 text-center animate-box">
					<div class="services" style="color: rgb(22, 5, 5);">
						<span class="icon">
							 <i class="icon-banknote"></i> 
						</span>
						<div class="desc">
							<h3><a href="#" style="color: rgb(15, 2, 2);">Individualized Attention</a></h3>
							<p>Quality private secondary schools are distinguished by how they handle students as individuals by responding to their specific learning needs.</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 text-center animate-box">
					<div class="services" style="color: rgb(19, 3, 3);">
						<span class="icon">
							 <i class="icon-lab2"></i> 
						</span>
						<div class="desc">
							<h3><a href="#" style="color: rgb(26, 4, 4);">Parental and Community Involvement</a></h3>
							<p>Quality private schools encourage the active involvement of parents in their child’s education. Their aim is to promote positive behavioral expectations, social teachings and a sense of community among students, faculty and parents.</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 text-center animate-box">
					<div class="services" style="color: rgb(26, 8, 8);">
						<span class="icon">
							 <i class="icon-photo"></i> 
						</span>
						<div class="desc ">
							<h3><a href="#" style="color: rgb(20, 2, 2);">Art &amp; Media</a></h3>
							<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 text-center animate-box">
					<div class="services" style="color: rgb(34, 6, 6);">
						<span class="icon">
							 <i class="icon-bubble3"></i> 
						</span>
						<div class="desc">
							<h3><a href="#" style="color: rgb(24, 4, 4);">Language</a></h3>
							<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	</div>

	<div id="fh5co-counter" class="fh5co-counters" style="background-image: url(http://localhost/matoshri_classes/assets/img/back2.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="row">
						<div class="col-md-3 col-sm-6 text-center animate-box">
							<span class="icon"><i class="icon-world"></i></span>
							<span class="fh5co-counter js-counter" data-from="0" data-to="7500" data-speed="5000" data-refresh-interval="50"></span>
							<span class="fh5co-counter-label">ImpleMentors</span>
						</div>
						<div class="col-md-3 col-sm-6 text-center animate-box">
							<span class="icon"><i class="icon-study"></i></span>
							<span class="fh5co-counter js-counter" data-from="0" data-to=" 500" data-speed="5000" data-refresh-interval="50"></span>
							<span class="fh5co-counter-label">lectures</span>
						</div>
						<div class="col-md-3 col-sm-6 text-center animate-box">
							<span class="icon"><i class="icon-head"></i></span>
							<span class="fh5co-counter js-counter" data-from="0" data-to="21" data-speed="5000" data-refresh-interval="50"></span>
							<span class="fh5co-counter-label">years of expertise</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-course">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
					<h2>Our Course</h2>
					<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 animate-box">
					<div class="course">
						<a href="#" class="course-img" style="background-image: url(images/project-1.jpg);">
						</a>
						<div class="desc">
							<h3><a href="#">9th 10th SSC</a></h3>
							<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
							<span><a href="#" class="btn btn-primary btn-sm btn-course">Take A Course</a></span>
						</div>
					</div>
				</div>
				<div class="col-md-6 animate-box">
					<div class="course">
						<a href="#" class="course-img" style="background-image: url(images/project-2.jpg);">
						</a>
						<div class="desc">
							<h3><a href="#">11th 12th Commerce</a></h3>
							<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
							<span><a href="#" class="btn btn-primary btn-sm btn-course">Take A Course</a></span>
						</div>
					</div>
				</div>
				<div class="col-md-6 animate-box">
					<div class="course">
						<a href="#" class="course-img" style="background-image: url(images/project-3.jpg);">
						</a>
						<div class="desc">
							<h3><a href="#">MBA BBA</a></h3>
							<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
							<span><a href="#" class="btn btn-primary btn-sm btn-course">Take A Course</a></span>
						</div>
					</div>
				</div>
				<div class="col-md-6 animate-box">
					<div class="course">
						<a href="#" class="course-img" style="background-image: url(images/project-4.jpg);">
						</a>
						<div class="desc">
							<h3><a href="#">Yashacha Mantra ShivTantra</a></h3>
							<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
							<span><a href="#" class="btn btn-primary btn-sm btn-course">Take A Course</a></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-testimonial" style="background-image: url(images/school.jpg);">
		<div class="overlay"></div>
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
					<h2><span>Testimonials</span></h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="row animate-box">
						<div class="owl-carousel owl-carousel-fullwidth">
							<div class="item">
								<div class="testimony-slide active text-center">
									<div class="user" style="background-image: url(images/person1.jpg);"></div>
									<span>Mary Walker<br><small>Students</small></span>
									<blockquote>
										<p>&ldquo;Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.&rdquo;</p>
									</blockquote>
								</div>
							</div>
							<div class="item">
								<div class="testimony-slide active text-center">
									<div class="user" style="background-image: url(images/person2.jpg);"></div>
									<span>Mike Smith<br><small>Students</small></span>
									<blockquote>
										<p>&ldquo;Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.&rdquo;</p>
									</blockquote>
								</div>
							</div>
							<div class="item">
								<div class="testimony-slide active text-center">
									<div class="user" style="background-image: url(images/person3.jpg);"></div>
									<span>Rita Jones<br><small>Teacher</small></span>
									<blockquote>
										<p>&ldquo;Far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.&rdquo;</p>
									</blockquote>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<div id="fh5co-gallery" class="fh5co-bg-section">
		<div class="row text-center">
			<h2><span>Instagram Gallery</span></h2>
		</div>
		<div class="row">
			<div class="col-md-3 col-padded">
				<a href="#" class="gallery" style="background-image: url(images/project-5.jpg);"></a>
			</div>
			<div class="col-md-3 col-padded">
				<a href="#" class="gallery" style="background-image: url(images/project-2.jpg);"></a>
			</div>
			<div class="col-md-3 col-padded">
				<a href="#" class="gallery" style="background-image: url(images/project-3.jpg);"></a>
			</div>
			<div class="col-md-3 col-padded">
				<a href="#" class="gallery" style="background-image: url(images/project-4.jpg);"></a>
			</div>
		</div>
	</div>
<script type="text/javascript">
	
	    $(".video-play").on('click', function(e) {
        e.preventDefault(); 
        var vidWrap = $(this).parent(),
            iframe = vidWrap.find('.video iframe'),
            iframeSrc = iframe.attr('src'),
            iframePlay = iframeSrc += "?autoplay=1";
        vidWrap.children('.video-thumbnail').fadeOut();
        vidWrap.children('.video-play').fadeOut();
        vidWrap.find('.video iframe').attr('src', iframePlay);


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\matoshri_classes\resources\views/webside/home.blade.php ENDPATH**/ ?>