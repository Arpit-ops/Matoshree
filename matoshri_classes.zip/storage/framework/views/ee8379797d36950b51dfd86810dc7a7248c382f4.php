<?php $__env->startSection('content'); ?>
<style type="text/css">
    .btn-info
    {
        margin-left: 30px!important;
    }
    .btn-danger
    {
        margin-left: 30px!important;
    }
    .btn-success
    {
        margin-left: 30px!important;
    }

    @media  only screen and (max-width: 600px) {
        .table-bordered {
            width:245px!important;
        }
        .pagemrgn
        {
            margin-top: 85px!important;
        }
    }

</style>

<!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/toaster.css')); ?>" />
<script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/toaster.min.js')); ?>"></script> -->


<div id="content-container"  style="padding-top: 0px;" >
    <div class="pageheader">
        <div id="page-content">
        <div class="panel col-md-10">
                <div class="panel-heading">
                    <h3 class="panel-title">Update Celebrity</h3>
                </div>
                <div class="panel-body">
                    <form method="post" action="<?php echo e(config('app.baseURL')); ?>/celebrity/<?php echo e($user->id); ?>"  enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group ">
                                        <label class="control-label"> Celebrity Name</label><label style="color:red;" class="control-label">*</label>
                                        <input type="text" id="demo-text-input" name="name" class="form-control" placeholder="Name" value="<?php echo e($user->name); ?>" maxlength="30" pattern="^(?:((([^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]'’,\-.\s])){1,}(['’,\-\.]){0,1}){2,}(([^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]'’,\-. ]))*(([ ]+){0,1}(((([^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]'’,\-\.\s])){1,})(['’\-,\.]){0,1}){2,}((([^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]'’,\-\.\s])){2,})?)*)$" required/>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                <div class="form-group ">
                                        <label class="control-label"> Celebrity Description</label><label style="color:red;" class="control-label">*</label>
                                        <input type="text" id="demo-text-input" name="description" class="form-control" placeholder="Celebrity Description" maxlength="300" value="<?php echo e($user->description); ?>" pattern="^(?:((([^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]'’,\-.\s])){1,}(['’,\-\.]){0,1}){2,}(([^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]'’,\-. ]))*(([ ]+){0,1}(((([^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]'’,\-\.\s])){1,})(['’\-,\.]){0,1}){2,}((([^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]'’,\-\.\s])){2,})?)*)$" required/>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                <div class="form-group ">
                                        <label class="control-label"> Facebook Link</label><label style="color:red;" class="control-label">*</label>
                                        <input type="text" id="demo-text-input" name="fblink" class="form-control" placeholder="Enter Facebook Link" value="<?php echo e($user->fb_link); ?>" maxlength="30"  required/>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                <div class="form-group ">
                                        <label class="control-label"> Instagram Link</label><label style="color:red;" class="control-label">*</label>
                                        <input type="text" id="demo-text-input" name="instalink" class="form-control" placeholder="Enter Instagram Link" value="<?php echo e($user->insta_link); ?>" maxlength="30"  required/>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                            <div class="col-sm-6">
                                    <div class="form-group">
                                        <label class="control-label">Amount</label><label style="color:red;" class="control-label">*</label>
                                        <input type="text" id="cno" name="amount" class="form-control" placeholder="Enter Amount" value="<?php echo e($user->amount); ?>" maxlength="10"  required/>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                     <div class="form-group">
                                        <label for="avatar">Choose a picture:</label>
                                         <input type="file" name="image" accept="image/png, image/jpeg" >
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="text-right">
                            <button class="btn btn-info" type="submit">Update Employee</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>

<script>

    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
    switch(type){
        case 'info':
        toastr.info("<?php echo e(Session::get('message')); ?>");
        break;
        
        case 'warning':
        toastr.warning("<?php echo e(Session::get('message')); ?>");
        break;
        case 'success':
        toastr.success("<?php echo e(Session::get('message')); ?>");
        break;
        case 'error':
        toastr.error("<?php echo e(Session::get('message')); ?>");
        break;
    }
    <?php endif; ?>
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp_workspace\htdocs\celebritybooking\resources\views/user/edit.blade.php ENDPATH**/ ?>