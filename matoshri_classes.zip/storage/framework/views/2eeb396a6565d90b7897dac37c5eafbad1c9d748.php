<?php $__env->startSection('content'); ?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<style type="text/css">
.btn-info
{
    margin-left: 30px!important;
}
.btn-danger
{
    margin-left: 30px!important;
}
.btn-success
{
    margin-left: 30px!important;
}

@media  only screen and (max-width: 600px) {
    .table-bordered {
        width:245px!important;
    }
    .pagemrgn
    {
        margin-top: 85px!important;
    }
}

</style>
<div id="content-container" style="padding-top: 0px;" >
<div class="pageheader">
<div id="page-content">
<div class="panel">

<div class="panel-heading ">
<h3 class="panel-title">All Celebrity &nbsp;&nbsp;  <?php echo $__env->make('layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<a href="<?php echo e(config('app.baseURL')); ?>/celebrity/add" class="pull-right">
<button class="btn btn-pink">Add Celebrity</button>
</a>
</h3>
</div>


<div class="panel-body">
<table class="table table-bordered col-md-12 col-sm-12" id="myTable" style="" >
<thead>
<tr>
<!-- <th>ID</th> -->
<th>Name</th>
<th>Profile Photo</th>
<th>Description</th>

<th>Facebook Link</th>
<th>Instagram Link</th>
<th>Amount</th>
<!-- <th>Status</th> -->
<th>Action</th>
</tr>
</thead>
<tbody>

</tbody>
</table>
</div>
</div>

</div>

</div>
</div>

<script type="text/javascript">
$(document).ready(function(){
    $("#myTable").dataTable({
        "processing": true,
        "serverSide": true,
        "responsive": true,
        ajax:"<?php echo e(config('app.baseURL')); ?>/celebrity/adddata/",
        "order":[
            [0,"asc"]
        ],
        "columns":[
            // {
            //     "mData":"id"
            // },
            {
                "mData":"name"
            },{
                          "targets":-1,
                          "mData": "profile_photo",
                          "bSortable": false,
                          "filter":false,
                          "mRender": function(data, type, row){
                            if(row.profile_photo==null){
                              return "Image Not Available";
                            }else{
                              return "<a href='<?php echo e(config('app.baseURL')); ?>/storage/app/"+row.profile_photo+"' target='_blank' download><img src='<?php echo e(config('app.baseURL')); ?>/storage/app/"+row.profile_photo+"' style='width:60px;'></a>";
                            }
                          },
                          
                        },
            {
                "mData":"description"
            },{
                "mData":"fb_link"
            },{
                "mData":"insta_link"
            },{
                "mData":"amount"
            },
            {
                "targets":-1,
                "mData": "Action",
                "bSortable": false,
                "ilter":false,
                "mRender": function(data, type, row){
                    if(row.is_active==0){
                        return "<a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/celebrity/"+ row.id+"><span><button type='submit' class='btn btn-primary'>Update</button></span></a><a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/celebrity/status/" + row.id+"><span><button type='submit' class='btn btn-danger'>Inactivate</button></span></a>";
                    }else{
                        return "<a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/celebrity/"+ row.id+"><span><button type='submit' class='btn btn-primary'>Update</button></span></a><a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/celebrity/status/" + row.id+"><span><button type='submit' class='btn btn-success'>Activate</button></span></a>";
                    }
                },
                
            },]
            
        });
    });
    </script>
    <script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
    switch(type){
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;
            
            case 'warning':
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break;
                case 'success':
                    toastr.success("<?php echo e(Session::get('message')); ?>");
                    break;
                    case 'error':
                        toastr.error("<?php echo e(Session::get('message')); ?>");
                        break;
                    }
                    <?php endif; ?>
                    </script>
                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp_workspace\htdocs\celebritybooking\resources\views/user/all.blade.php ENDPATH**/ ?>