<?php $__env->startSection('content'); ?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<style type="text/css">
.btn-info
{
    margin-left: 30px!important;
}
.btn-danger
{
    margin-left: 30px!important;
}
.btn-success
{
    margin-left: 30px!important;
}

@media  only screen and (max-width: 600px) {
    .table-bordered {
        width:245px!important;
    }
    .pagemrgn
    {
        margin-top: 85px!important;
    }
}

</style>
<div id="content-container" style="padding-top: 0px;" >
<div class="pageheader">
<div id="page-content">
<div class="panel">

<div class="panel-heading ">
<h3 class="panel-title">All Cunstomers <?php echo $__env->make('layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</h3>
</div>


<div class="panel-body">
<table class="table table-bordered col-md-12 col-sm-12" id="myTable" style="" >
<thead>
<tr>
<th>Name</th>
<th>Address</th>
<th>Contact Number</th>
<th>Action</th>
</tr>
</thead>
<tbody>

</tbody>
</table>
</div>
</div>

</div>

</div>
</div>

<script type="text/javascript">
$(document).ready(function(){
    $("#myTable").dataTable({
        "processing": true,
        "serverSide": true,
        "responsive": true,
        ajax:"<?php echo e(config('app.baseURL')); ?>/customer/alldata/",
        "order":[
            [0,"asc"]
        ],
        "columns":[
            // {
            //     "mData":"id"
            // },
            {
                "mData":"name"
            },{
                "mData":"address"
            },{
                "mData":"contact_number"
            },
            {
                "targets":-1,
                "mData": "Action",
                "bSortable": false,
                "ilter":false,
                "mRender": function(data, type, row){
                    if(row.is_active==0){
                        return "<a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/customer/status/" + row.id+"><span><button type='submit' class='btn btn-danger'>Inactivate</button></span></a>";
                    }else{
                        return "<a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/customer/status/" + row.id+"><span><button type='submit' class='btn btn-success'>Activate</button></span></a>";
                    }
                },
                
            },]
            
        });
    });
    </script>
    <script>
    <?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
    switch(type){
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;
            
            case 'warning':
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break;
                case 'success':
                    toastr.success("<?php echo e(Session::get('message')); ?>");
                    break;
                    case 'error':
                        toastr.error("<?php echo e(Session::get('message')); ?>");
                        break;
                    }
                    <?php endif; ?>
                    </script>
                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\celebritybooking\resources\views/customer/all.blade.php ENDPATH**/ ?>