<?php $__env->startSection('content'); ?>


<style>
  .dataTables_length{

  }
  
    @media  only screen and (max-width: 600px) {
 .table
 {
   width: 300px!important;
 }
}

</style>

<div id="content-container">

  <div class="pageheader">


    <div id="page-content">

      <div class="panel">

                        <!--     <div class="panel-heading">
                              <h3 class="panel-title">Add Row</h3>
                            </div> -->
                      <!--       <div id="demo-custom-toolbar2" class="table-toolbar-left">
                             <a href="<?php echo e(config('app.baseURL')); ?>/user/loction"><button id="demo-dt-addrow-btn" class="btn btn-pink">Add row</button></a>
                           </div> -->

                           <div class="panel-heading ">
                            <h3 class="panel-title">Location List <a href="<?php echo e(config('app.baseURL')); ?>/map/<?php echo e($user->id); ?>" target='_blank' id="url" class="pull-right"><button class="btn btn-pink">Show Map</button></a></h3>

                          </div>
                          <div class="panel-body">
                            <div id="demo-dp-component">
                              <div class="input-group date col-lg-3" style="margin-left: 1130px;float: left;">
                                <input type="date" class="form-control" name="date" id="date" value="<?php echo e(old('date')); ?>" style="width:181px;margin-left: -138px">
                                <span class="input-group-addon" ><button  class="btn btn-pink" id="filter" style="margin-left: -405px;margin-bottom: 8px">Filter</button></span> 
                                
                              </div>



                            </div>
                            <table class="table table-bordered col-md-12 col-sm-12" id="myTable"  style="">

                              <thead>
                                <tr>
                                 <th>Location Id</th>
                                 <th>Latitude</th>
                                 <th>Longitude</th>
                                 <th>Created At</th>

                                 <th>Location</th>
                                 
                                 <!-- <th>User Name</th> -->
                                 <!-- <th>Action</th> -->
                               </tr>
                             </thead>
                             <tbody>

                             </tbody>
                           </table>
                         </div>
                       </div>
                       <!--===================================================-->
                       <!-- End Add Row -->
                     </div>
                     <!--===================================================-->
                     <!--End page content-->
                   </div>


  <!-- 
                     <script type="text/javascript">
                      $(document).ready(function(){
                        $("#myTable").dataTable({
                          "processing": true,
                          "serverSide": true,
                          "responsive": true,
                          ajax:"<?php echo e(config('app.baseURL')); ?>/location/alldata/<?php echo e($user->id); ?>?&date="+date,
                          "order":[
                          [0,"asc"]
                          ],
                          "columns":[
                          {
                            "mData":"location_id"
                          },{
                            "mData":"latitude"
                          },{
                            "mData":"longitude"
                          },
                          {
                            "mData":"created_at"
                          },
                          {  
                            "targets":-1,
                            "mData": "Action",
                            "bSortable": false,
                            "ilter":false,
                            "mRender": function(data, type, row){
                             
                                return " <a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/single-map/" + row.location_id+"><span><button type='submit' class='btn btn-info'>Location</button></span></a> ";
                             
                              
                            },

                          },]
                        });
                      });
                    </script> -->
                    <script>

                      <?php if(Session::has('message')): ?>
                      var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
                      switch(type){
                        case 'info':
                        toastr.info("<?php echo e(Session::get('message')); ?>");
                        break;

                        case 'warning':
                        toastr.warning("<?php echo e(Session::get('message')); ?>");
                        break;
                        case 'success':
                        toastr.success("<?php echo e(Session::get('message')); ?>");
                        break;
                        case 'error':
                        toastr.error("<?php echo e(Session::get('message')); ?>");
                        break;
                      }
                      <?php endif; ?>
                    </script>



                    <script type="text/javascript">

                      $('#date').change(function(){
                        localStorage.clear();

                       var date=$("#date").val();
                       
                       localStorage.setItem("date", date);

                       var date = localStorage.getItem('date');



                       $('#url').attr("href","<?php echo e(config('app.baseURL')); ?>/map/<?php echo e($user->id); ?>?date="+date);
                     });

                      $(document).ready(function(){
                        var today = new Date();
                        var dd = String(today.getDate()).padStart(2, '0');
                        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                        var yyyy = today.getFullYear();

                        today = mm + '/' + dd + '/' + yyyy;
                        document.getElementById("date").defaultValue = today;

                        $("#date").val(today);
                        datatable();

                        $("#filter").click(function(){
                          $("#myTable").DataTable().destroy();
                          datatable();
                        });
                      });
                    </script>

                    <script type="text/javascript">
                      function datatable(){
                        var date=$("#date").val();

                        /*if(!localStorage.getItem('date')){
                          localStorage.setItem("date", date);
                        }*/
                        // var date = localStorage.getItem("date");

                        $("#myTable").dataTable({
                          "processing": true,
                          "serverSide": true,
                          "responsive": true,
                          "stateSave": true,
                          ajax:"<?php echo e(config('app.baseURL')); ?>/location/alldata/<?php echo e($user->id); ?>?date="+date,
                          "order":[
                          [0,"asc"]
                          ],
                          "columns":[
                          {
                            "mData":"location_id"
                          },{
                            "mData":"latitude"
                          },{
                            "mData":"longitude"
                          },
                          {
                            "mData":"created_at"
                          },
                          {  
                            "targets":-1,
                            "mData": "Action",
                            "bSortable": false,
                            "ilter":false,
                            "mRender": function(data, type, row){

                              return " <a class=datatable-left-link target='_blank' href=<?php echo e(config('app.baseURL')); ?>/single-map/" + row.location_id+"><span><button type='submit' class='btn btn-info'>Location</button></span></a> ";


                            },

                          },]
                        });
                      }
                    </script>
                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\employeetracking.com\resources\views/user/user_location.blade.php ENDPATH**/ ?>