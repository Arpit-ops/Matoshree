<?php $__env->startSection('content'); ?>
<!-- <style type="text/css">
  div.dataTables_filter {
    text-align: right;
    margin-left: 1100px;
}
</style> -->

<style type="text/css">
  .btn-info
  {
    margin-left: 30px!important;
  }
  .btn-danger
  {
     margin-left: 30px!important;
  }
  .btn-success
  {
    margin-left: 30px!important;
  }

@media  only screen and (max-width: 600px) {
 .table-bordered {
   width:245px!important;
  }
  .pagemrgn
  {
    margin-top: 85px!important;
  }
}

.btn {
    display: inline-block;
    padding: 8px 6px !important;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}

</style>
<div id="content-container">

  <div class="pageheader">
                       
                        
                        <div id="page-content" class="pagemrgn">

                          <div class="panel">
                            <div class="panel-heading ">
                              <h3 class="panel-title">Employee List <a href="<?php echo e(config('app.baseURL')); ?>/employee/add" class="pull-right"><button  class="btn btn-pink">Add Employee</button></a></h3>
                              
                            </div>
                            <div id="demo-custom-toolbar2" class="table-toolbar-left">
                             



                           </div>
                           <div class="panel-body">
                            <table class="table table-bordered col-md-12 col-sm-12" id="myTable"  style="" >
                              <thead>
                                <tr>
                                 <th>ID</th>
                                 <th>Name</th>
                                 <th>Mobile no</th>
                                 <th>email</th>
                                 
                                 <th>Address</th>
                                 <!-- <th>Status</th> -->
                                 <th>Action</th>
                               </tr>
                             </thead>
                             <tbody>

                             </tbody>
                           </table>
                         </div>
                       </div>
                       <!--===================================================-->
                       <!-- End Add Row -->
                     </div>
                     <!--===================================================-->
                     <!--End page content-->
                   </div>

                   <script type="text/javascript">
                    $(document).ready(function(){
                      $("#myTable").dataTable({
                        "processing": true,
                        "serverSide": true,
                        "responsive": true,
                        ajax:"<?php echo e(config('app.baseURL')); ?>/employee/allData/",
                        "order":[
                        [0,"asc"]
                        ],
                        "columns":[
                        {
                          "mData":"id"
                        },{
                          "mData":"name"
                        },{
                          "mData":"contact_number"
                        },{
                          "mData":"email"
                        },
                        {
                          "mData":"address"
                        },/*{
                          "mData":"created_at"
                        },{
                          "mData":"updated_at"
                        },*/
                        {  
                          "targets":-1,
                          "mData": "Action",
                          "bSortable": false,
                          "ilter":false,
                          "mRender": function(data, type, row){
                            if(row.is_active==0){
                              return "<a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/employee/"+ row.id+"><span><button type='submit' class='btn btn-primary'>Details</button></span></a> <a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/location/" + row.id+"><span><button type='submit' class='btn btn-info'>Location</button></span></a> <a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/user-inactive/" + row.id+"><span><button type='submit' class='btn btn-danger'>Inactivate</button></span></a>";
                            }else{
                              return "<a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/employee/" + row.id+"><span><button type='submit' class='btn btn-primary'>Details</button></span></a> <a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/location/" + row.id+"><span><button type='submit' class='btn btn-info'>Location1</button></span></a> <a class=datatable-left-link href=<?php echo e(config('app.baseURL')); ?>/user-active/" + row.id+"><span><button type='submit' class='btn btn-success'>Activate</button></span></a>";
                            }
                          },

                        },]

                      });
                    });
                  </script>
                  <script>

                    <?php if(Session::has('message')): ?>
                    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
                    switch(type){
                      case 'info':
                      toastr.info("<?php echo e(Session::get('message')); ?>");
                      break;

                      case 'warning':
                      toastr.warning("<?php echo e(Session::get('message')); ?>");
                      break;
                      case 'success':
                      toastr.success("<?php echo e(Session::get('message')); ?>");
                      break;
                      case 'error':
                      toastr.error("<?php echo e(Session::get('message')); ?>");
                      break;
                    }
                    <?php endif; ?>
                  </script>
                  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_workspace\htdocs\employeetracking.com\resources\views/user/all.blade.php ENDPATH**/ ?>