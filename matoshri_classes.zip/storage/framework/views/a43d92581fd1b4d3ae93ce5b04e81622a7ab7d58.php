<header id="navbar">
                <div id="navbar-container" class="boxed">
                    <!--Brand logo & name-->
                    <!--================================-->
                    <div class="navbar-header">
                        <a href="<?php echo e(config('app.baseURL')); ?>/employee/all" class="navbar-brand" style="width: 320px !important;">
                            <i class=""></i>
                            <div class="brand-title">
                            
                                 <span class="brand-text " style="font-size: 24px;"><b>EmployeeTracking</b></span>

                            </div>


                        </a>
                    </div>
                    <!--================================-->
                    <!--End brand logo & name-->
                    <!--Navbar Dropdown-->
                    <!--================================-->
                    <div class="navbar-content clearfix">
                        <ul class="nav navbar-top-links pull-left">
                            <!--Messages Dropdown-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <li class="dropdown">
                         <!--        <a href="#" data-toggle="dropdown" class="dropdown-toggle">
                                <i class="fa fa-envelope fa-lg"></i>
                                <span class="badge badge-header badge-warning">9</span>
                                </a> -->
                                <!--Message dropdown menu-->
                                
                            </li>
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <!--End message dropdown-->
                            <!--Notification dropdown-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <li class="dropdown">
                               <!--  <a href="#" data-toggle="dropdown" class="dropdown-toggle"> <i class="fa fa-bell fa-lg"></i> <span class="badge badge-header badge-danger">5</span> </a> -->
                                <!--Notification dropdown menu-->
                                
                            </li>
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <!--End notifications dropdown-->
                        </ul>
                        <ul class="nav navbar-top-links pull-right">
                            <!--Profile toogle button-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                         <!--    <li class="" id="">
                                <a class=""  href="<?php echo e(config('app.baseURL')); ?>/employee/all" role="">
                                <span class="" style="margin-left: -1000px">Employee</span>
                                </a>
                            </li> -->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <!--End Profile toogle button-->
                            <!--User dropdown-->
                            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                            <li id="dropdown-user" class="dropdown">
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle text-right">
                                    <span class="pull-right"> <!-- <img class="img-circle img-user media-object" src="<?php echo e(asset('img\av1.png')); ?>" alt="Profile Picture"> --> </span>
                                    <div>Employee</div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right with-arrow">
                                    <!-- User dropdown menu -->
                                    <ul class="head-list">
                                        <li>
                                            <!-- <a href="#"> <i class="fa fa-user fa-fw"></i> Profile </a> -->
                                        </li>
                                        
                                       
                                       
                                        <li>
                                            <a href="<?php echo e(config('app.baseURL')); ?>/changepassword"> <i class="fa fa-lock"></i> Change Password </a>
                                        </li>
                                         <li>
                                            <a href="<?php echo e(route('logout')); ?>"> <i class="fa fa-sign-out fa-fw"></i> Logout </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
              
                        </ul>
                    </div>
                    <!--================================-->
                    <!--End Navbar Dropdown-->
                    <nav class="navbar navbar-default megamenu">
                        <div class="navbar-header">
                            <button type="button" data-toggle="collapse" data-target="#defaultmenu" class="navbar-toggle">
                            <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
                            </button>
                        </div>
                        <!-- end navbar-header -->
                        <div id="defaultmenu" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <!-- standard drop down -->
                                <li class="dropdown">
                                   <!--  <a href="<?php echo e(config('app.baseURL')); ?>/" data-toggle="dropdown" class="dropdown-toggle"> Home <b class=""></b></a> -->
                                  <!--   <ul class="dropdown-menu" role="menu">
                                        <li><a href="index-1.htm">Dashboard V1 </a></li>
                                        <li><a href="dashboard-v2.htm">Dashboard V2 </a></li>
                                    </ul> -->
                                    <!-- end dropdown-menu -->
                                </li>
                                <!-- end standard drop down -->
                                <!-- standard drop down -->
                                
                                <!-- end standard drop down -->
                                <!-- standard drop down -->
                                 <li>
                                    <a href="<?php echo e(config('app.baseURL')); ?>/employee/all"> Employee </a>
                                </li>
                              <li>
                                    <a href="<?php echo e(config('app.baseURL')); ?>/location/all"> Location </a>
                                </li>
                               <!--  <li>
                                    <a href="<?php echo e(config('app.baseURL')); ?>/product/all"> Product </a>
                                </li> -->
                               
                                <!-- <li>
                                    <a href="<?php echo e(config('app.baseURL')); ?>/all"> Widgets </a>
                                </li> -->
                          
                               
                            </ul>
                            <!-- end nav navbar-nav -->
                        </div>
                        <!-- end #navbar-collapse-1 -->
                    </nav>
                    <!-- end navbar navbar-default megamenu -->
                </div>
            </header><?php /**PATH D:\xampp_workspace\htdocs\employeetracking.com\resources\views/layouts/header.blade.php ENDPATH**/ ?>