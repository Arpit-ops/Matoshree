<?php $__env->startSection('content'); ?>
<body>
    
<h1> 
Wellcome <?php echo e(Auth::user()->name); ?> !!!!
</h1>
</body>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\matoshri_classes\resources\views/admin_home.blade.php ENDPATH**/ ?>