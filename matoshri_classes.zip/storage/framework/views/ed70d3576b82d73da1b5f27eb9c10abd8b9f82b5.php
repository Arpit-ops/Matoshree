<?php if($message = Session::get('success')): ?>  
<div class="alert alert-success" role="alert">     
        <?php echo e($message); ?>  
</div>  
<?php endif; ?>  
  
<?php if($message = Session::get('error')): ?>  
<div class="alert alert-dark" role="alert">     
        <?php echo e($message); ?>  
</div>  
<?php endif; ?>  
  
<?php if($message = Session::get('warning')): ?>  
<div class="alert alert-warning" role="alert">     
    <?php echo e($message); ?>  
</div>  
<?php endif; ?>  
  
<?php if($message = Session::get('info')): ?>  
<div class="alert alert-info" role="alert">     
    <?php echo e($message); ?>  
</div>  
<?php endif; ?>  
  
<?php if($errors->any()): ?>  
<div class="alert alert-danger" role="alert">     
    Please check the form below for errors  
</div>  
<?php endif; ?>  <?php /**PATH D:\xampp\htdocs\matoshri_classes\resources\views/flash-message.blade.php ENDPATH**/ ?>